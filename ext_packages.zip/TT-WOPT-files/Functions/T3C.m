
function [X_hat,G_opted, logger]=T3C(varargin)

% The 1st and 2nd input must be X and W
if (nargin == 0||nargin == 1)
    X_hat=0;
    G_opted=0;
    fprintf('Not enough input.\n');
else
    
    ip = inputParser;
    ip.addParamValue('Tol', 0, @isscalar);
    ip.addParamValue('Rank', 16*ones(1,ndims(varargin{1})-1), @ismatrix);
    ip.addParamValue('MaxIter', 5e2, @isscalar);
    ip.addParamValue('Alg', 'TTWOPT', @ischar);
    ip.parse(varargin{4:end});
    
    Tol = ip.Results.Tol;
    Rank = ip.Results.Rank;
    MaxIter = ip.Results.MaxIter;
    Alg = ip.Results.Alg;
  
    X=varargin{1};
    W=varargin{2};
    G0 = varargin{3}; %init

    S=size(X);
    N=numel(S);
    r=Rank;
            % TTWOPT
    if strcmp(Alg,'TTWOPT')
        fprintf('------ TTWOPT ------ \n\n');
        G0_v=Gm2Gv(Gt2Gm(G0));

        
        options = lbfgs('defaults');
        options.MaxIters = MaxIter;
        options.StopTol = Tol;
        options.RelFuncTol = 1.0e-100; % Tol^2   
        options.DisplayIters = 20;
        options.MaxFuncEvals=1.0e+100;
        options.TraceRelFunc = true;
        options.TraceFunc = true;
        
        out=lbfgs(@(G) tt_wfg(W.*X,W,G,r),G0_v, options);
        G_opted=Gm2Gt(Gv2Gm(out.X,S,r),r); % core tensors
        X_hat=coreten2tt(G_opted);

        if nargout > 2
           logger = out;
        end
        %X_hat(W==1)=X(W==1);
           % TTSGD     
    elseif strcmp(Alg,'TTSGD')
        fprintf('------ TTSGD ------ \n\n');
        G_opted = tt_sgd(X,W,G0,'Rank',r,'MaxIter',MaxIter,'Tol',Tol);
        X_hat=coreten2tt(G_opted);
        %X_hat(W==1)=X(W==1);
        if nargout > 2
           logger = {};
        end
    end
end
end