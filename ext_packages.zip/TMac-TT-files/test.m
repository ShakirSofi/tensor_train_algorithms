% test
clear all; clc;

             
%% ================= GENERATE TT-LOW-RANK TENSOR =================
size_tens = [10, 10, 10, 10, 10];
N = length(size_tens);
TTrank = [1 3 3 3 4 1];
rate_miss_fibers = 0.5; 
snr=35;
% Generate TT tensor
[G, ~] = rand_tt(size_tens, TTrank);
X = TT_full(G);

Xnoisy = noisy(X, snr);

fprintf('Generated TT-low-rank tensor.\n');

%% ================= SAMPLING =================
% Sr: binary tensor of size I1 x I2 x .. x I_{N-1}.
Sr = false(size_tens(1:N-1));
%Sr = ensure_TTunfold_row_connectivity(Sr);

% Set entries to true to achieve the desired rate.
Sr = binary_rnd_Sr(Sr, 1-rate_miss_fibers); 

W = repmat(Sr, [ones(1,N-1) size_tens(N)]);
ind = find(W);
Wc = ~W;

Xm = W.*Xnoisy;
Xm(Xm==0) = nan;

% Set parameters for TMac-TT
tol = 1e-7;
maxiter = 1000;
thl = 0.1;

%% ================= RUN YOUR METHOD =================
fprintf('Running TMacTTCompletion...\n');
[Out, ~] = TMacTTCompletion(Xm, ind, thl, maxiter, tol);
Xhat = Out.MS;
err = Out.err;


%% ================= METRICS =================
RSE_total = norm(Xhat(:) - X(:)) / norm(X(:));
RSE_obs   = norm(Xhat(ind) - X(ind)) / norm(X(ind));

fprintf('RSE (total)    = %.3e\n', RSE_total);
fprintf('RSE (observed) = %.3e\n', RSE_obs);

%% ================= CONVERGENCE =================
figure;
semilogy(err,'LineWidth',1.5);
xlabel('Iteration');
ylabel('Relative Error');
title('TMac-TT Convergence');
grid on;