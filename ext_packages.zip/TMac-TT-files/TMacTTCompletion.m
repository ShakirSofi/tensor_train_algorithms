function [Out,Xmiss] = TMacTTCompletion(X, known, thl, maxiter, tol)
    %Reference : Bengua, Johann A., et al. "Efficient tensor completion for color image and video recovery:
    % Low-rank tensor train." IEEE Transactions on Image Processing 26.5 (2017): 2466-2479.

    %% Missing data
    Nway = size(X); N = numel(Nway);
    Xkn = X(known);
    Omega = zeros(Nway);
    Omega(known) = 1;
    Omega = logical(Omega);
    Out.Omega = Omega;
    Xmiss = Omega.*X; 


    %% TMac-TT Algorithm  
    %thl = [0.2];       % Adjust this value for different thresholds % Adjust this value for different thresholds
    %tol = 10^(-4);      % tol from Eq. (43)
    %maxiter = 1000;     % max iterations
    RSl = zeros(1,length(thl));MSl = cell(1,length(thl));relerrSl = MSl;
    for k=1:length(thl)
        th = thl(k);
        [~,ranktube] = SVD_MPS_Rank_Estimation(X, th);   % Initial TT ranks
        [MSl{k},~,~,relerrSl{k}] = TMacTT(Xkn,known,Nway,N,ranktube,tol,maxiter);    
        RSl(k) = RSE(MSl{k}(:),X(:));
    end
    %Choose the minimum RSE
    [Out.RSEmin, Idx] = min(RSl);
    Out.muf = thl(Idx);
    Out.MS = MSl{Idx};
    Out.err = relerrSl{Idx};


end

%% Utilities

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TMac-TT
% Time: 30/06/2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [M,X01,Y01,relerr] = TMacTT(data,known,Nway,N,ranktube,tol,maxiter)
    % Compute the weights for each matrix
    lambda = weightTC(Nway);
    % Initialization
    M = initialization_M(Nway,known,data);
    [X0,Y0] = initialMatrix(N,Nway,ranktube);
    opts.X0 = X0; opts.Y0 = Y0;opts.lambda = lambda;opts.maxit = maxiter;opts.M0 =M;
    [M,X01,Y01,relerr] = GlobalTMP(data,known,Nway,opts,tol);
end
%%
function [X0,Y0] = initialMatrix(N,Nway,ranktube)
    X0 = cell(1,N-1);Y0 = cell(1,N-1);
    dimL = zeros(1,N-1);
    dimR = zeros(1,N-1);
    IL = 1;
    for k = 1:N-1
        dimL(k) = IL*Nway(k);
        dimR(k) = prod(Nway)/dimL(k);
        %
        X0{k} = randn(dimL(k),ranktube(k));
        Y0{k} = randn(ranktube(k),dimR(k));
        %uniform distribution on the unit sphere
        X0{k} = bsxfun(@rdivide,X0{k},sqrt(sum(X0{k}.^2,1)));
        Y0{k} = bsxfun(@rdivide,Y0{k},sqrt(sum(Y0{k}.^2,2)));
        %
        IL = dimL(k);
    end   
end
%%
function [M, X,Y,relerr] = GlobalTMP(data,known,Nway,opts,tol)

    X = opts.X0; Y = opts.Y0; lambda = opts.lambda;
    N = length(Nway);
    if isfield(opts,'M0')
        M = opts.M0;
        M = reshape(M,Nway);
    else
        M = zeros(Nway);
        M(known) = data;
    end
    normM = norm(data(:),'fro');
    Xsq = cell(1,N-1);
    k = 1;
    relerr = [];
    maxit = opts.maxit;
    relerr(1) = 1;
  
    while relerr(k) > tol
        k = k+1;
        Mlast = M;
        if mod(k, 20) == 0
          fprintf('Tmac-TT: iterations = %d   difference=%f\n', k, relerr(k-1));
        end
        % update (X,Y)
        for n = 1:N-1
            Mn = reshape(M,[size(X{n},1) size(Y{n},2)]);
            X{n} = Mn*Y{n}';
            Xsq{n} = X{n}'*X{n};
            Y{n} = pinv(Xsq{n})*X{n}'*Mn;
        end
        % update M
        Mn = X{1}*Y{1};
        M = lambda(1)*Mn;
        M = reshape(M,Nway);
        for n = 2:N-1
            Mn = X{n}*Y{n};
            Mn = reshape(Mn,Nway);
            M = M+lambda(n)*Mn;
        end

        M(known) = data;


        % Calculate relative error
        relerr(k) = abs(norm(M(:)-Mlast(:)) / normM);

        % check stopping criterion
        if k > maxit % || (relerr(k)-relerr(k-1) > 0)
            % update M , this better in noisy observation case
            Mn = X{1}*Y{1};
            M = lambda(1)*Mn;
            M = reshape(M,Nway);
            for n = 2:N-1
                Mn = X{n}*Y{n};
                Mn = reshape(Mn,Nway);
                M = M+lambda(n)*Mn;
            end

            break
        end


    end
    relerr(k) = abs(norm(M(:)-Mlast(:)) / normM);
    fprintf('TMac-TT ends: total iterations = %d   difference=%f\n\n', k, relerr(k));
end